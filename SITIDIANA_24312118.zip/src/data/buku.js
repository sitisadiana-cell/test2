// src/data/buku.js
const buku = [
 { id: 1, judul: 'Dasar Jaringan Komputer', penulis: 'Dr. Heni Sulistiani', stok: 8, kategori: 'Referensi' },
 { id: 2, judul: 'Interaksi Manusia Komputer', penulis: 'Yusra Fernando, M.Kom.', stok: 3, kategori:
'Skripsi' },
 { id: 3, judul: 'Bisnis Digital', penulis: 'Sari Wulandari, M.Kom.', stok: 0, kategori: 'Referensi' },
 { id: 4, judul: 'Pemrograman JavaScript', penulis: 'Budi Haryanto', stok: 5, kategori: 'Novel' },
 { id: 5, judul: 'Basis Data', penulis: 'Siti Aminah, M.Kom.', stok: 4, kategori: 'Referensi' },
 // TODO 1: tambah minimal 2 buku lagi (id unik)
];
// TODO 2: export DUA hal:
// - export default array `buku`
export const totalStok = list => list.reduce((t, b) => t + b.stok, 0):
export const formatJudul = (judul, penulis) => $(judul) oleh $(penulis);
export default buku;
// - export named `totalStok(list)` => jumlahkan stok pakai arrow + reduce
// TODO 3: buat fungsi `formatJudul(judul, penulis)` memakai TEMPLATE LITERAL