<script setup>
<script setup>
// TODO 5: import DaftarBuku from './components/KartuBuku.vue'
import DaftarBuku from './components/KartuBuku.vue'
</script>
<template>
 <h1>Kuis Praktikum Perpustakaan</h1>
 
 <!-- TODO 6: panggil <KartuBuku /> -->
 <KartuBuku />
</template>
