<script setup>
// TODO 1: import KartuBuku dari "@/components/KartuBuku.vue"
</script>
<template>
 <section class="daftar">
 <h2>Daftar Buku</h2>
 <!-- TODO 2: panggil <KartuBuku /> DUA KALI -->
 <KartuBuku />
 <KartuBuku />
 </section>
</template>
<style scoped>
/* TODO 3: style .daftar produk *
.daftar {
    background #f4f4f4;
    padding 12px;
    border-radius 8px;
}
</style>