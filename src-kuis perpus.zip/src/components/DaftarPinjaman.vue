<script setup>
import { ref } from 'vue'
const pinjaman = ref([
 { id: 1, judul: 'Pemrograman JavaScript', kembali: true },
 { id: 2, judul: 'Basis Data', kembali: false },
 { id: 5, judul: 'Basis Data', kembali: true},
 // TODO 1: tambah minimal 1 item lagi (id unik)
])
</script>
<template>
 <ul>
 <!-- TODO 2: v-for + :key="p.id" + :class="{ kembali: p.kembali }"
 tampilkan judul + status ternary (Kembali / Belum) -->
 </ul>
 <!-- TODO 3: empty state v-if saat list kosong -> 'Tidak ada pinjaman' -->
</template>
<style scoped>
/* TODO 4: .kembali { text-decoration: line-through; color: #888; } */
</style>