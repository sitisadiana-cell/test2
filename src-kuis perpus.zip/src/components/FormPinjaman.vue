<script setup>
import { ref } from 'vue'
// TODO 1: ref:
// nama -> '' (input teks, WAJIB modifier .trim)
// jumlah -> 0 (input angka, WAJIB modifier .number)
// kategori -> 'Buku Novel' (select)
// setuju -> false (checkbox)
</script>
<template>
 <section class="form">
 <h2>Form Peminjaman</h2>
 <!-- TODO 2: input teks nama (pakai .trim) -->
 <!-- TODO 3: input angka jumlah (pakai .number) -->
 <!-- TODO 4: select kategori: Novel / Referensi / Skripsi / Majalah -->
 <!-- TODO 5: checkbox setuju -->
 <!-- TODO 6: preview. Aturan:
 - nama kosong -> 'Nama belum diisi' (operator ||)
 - jumlah kosong -> '-'
 - setuju -> 'Ya' / 'Tidak' (ternary) -->
 <div class="preview">...</div>
 </section>
</template>
<style scoped>
.preview { border: 1px dashed #999; border-radius: 8px; padding: 12px; margin-top: 12px; }
</style>