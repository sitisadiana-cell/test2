<script setup>
import { ref } from 'vue'
// TODO 1: buat ref: nama ("Citra Lestari"), pinjam (34), kembali (30), rating (90)
const nama = ref('Citra Lestari')
const pinjam = ref(34)
const kembali = ref(30)
const rating = ref(90)
</script>

<template>
 <div class="kartu">
  <h1>Halo {{ toUpperCase }}!</h1>
  <p>persen pengembalian (kembali / pinjam * 100)</p>
  <p> persen >= 75 -> 'RAJIN'</p>
  <p>rating format "Rating: 90% (baik)"</p>

 <!-- TODO 2: tampilkan nama dalam HURUF BESAR (toUpperCase) -->
 <!-- TODO 3: persen pengembalian (kembali / pinjam * 100)
 dibulatkan 1 desimal (toFixed(1)) -->
 <!-- TODO 4: status TERNARY: persen >= 75 -> 'RAJIN', selain itu 'PERINGATAN' -->
 <!-- TODO 5: rating format "Rating: 90% (baik)"
 ternary: >= 85 -> 'baik', selain itu 'kurang' -->
 </div>
</template>
<style scoped>
.kartu { border: 2px solid #1F3A5F; border-radius: 8px; padding: 12px; }
</style>