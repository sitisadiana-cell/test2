// src/components/KartuBuku.vue
<script setup>
// TODO 1: import data buku dari "@/data/buku.js"
// TODO 2: ambil SEMUA buku ke variabel `daftarBuku`
</script>
<template>
 <div class="kartu">
 <!-- TODO 3: tampilkan setiap buku pakai v-for + :key="b.id"
 (sementara boleh pakai v-for, detail P5) -->
 </div>
</template>
<style scoped>
/* TODO 4: gaya .kartu:
 border: 2px solid #981717; border-radius: 8px; padding: 12px */
</style>