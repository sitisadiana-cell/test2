<script setup>
import { ref } from 'vue'
// TODO 1: ref:
// sampul -> 'https://vuejs.org/images/logo.png'
// katalog -> 'https://vuejs.org/guide/introduction.html'
// tersedia -> true (boolean)
// warna -> 'peru' | ukuran -> 16
</script>
<template>
 <section>
 <!-- TODO 2: PERBAIKI baris ini (atribut TIDAK boleh pakai {{ }}) -->
 <img src="{{ sampul }}" alt="Sampul buku" width="80" />
 <!-- TODO 3: tautan ke katalog memakai :href -->
 <!-- TODO 4: tombol Pinjam dinonaktifkan saat tersedia = false (:disabled + !) -->
 <!-- TODO 5: :class object syntax { terpilih: tersedia } -->
 <!-- TODO 6: :class array syntax [sampul, tersedia && 'pilih'] -->
 <!-- TODO 7: :style object { color: warna, fontSize: ukuran + 'px' } -->
 </section>
</template>
<style scoped>
/* TODO 8: .terpilih (border biru #9f1717) dan .pilih (font-weight: bold) */
</style>