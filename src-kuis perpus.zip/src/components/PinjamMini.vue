<script setup>
import { ref, computed } from 'vue'
const judulBaru = ref('')
const pinjaman = ref([])
let id = 1
// TODO 1: function tambah() -> push { id: id++, judul, kembali: false }, tolak bila kosong
// TODO 2: function hapus(i) -> splice
// TODO 3: function selesaikan(p) -> balik p.kembali (dipanggil dari @click)
// TODO 4: computed total / kembali / belum
</script>
<template>
 <h2>Pinjaman Saya ({{ total }} judul)</h2>
 <!-- TODO 5: <form @submit.prevent="tambah"> berisi
 input v-model="judulBaru" + tombol type="submit" -->
 <ul>
 <!-- TODO 6: v-for + :key="p.id" ; checkbox v-model="p.kembali" ;
 judul :class { kembali } ; tombol Hapus @click="hapus(i)" -->
 </ul>
 <!-- TODO 7: baris hitung: Total: X | Kembali: Y | Belum: Z -->
 <!-- TODO 8: empty state v-if saat list kosong -> 'Tidak ada pinjaman' -->
</template>
<style scoped>
.kembali { text-decoration: line-through; color: #888; }
</style>
