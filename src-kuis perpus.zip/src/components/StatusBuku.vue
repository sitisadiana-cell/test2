<script setup>
import { ref } from 'vue'
// TODO 1: ref stok = 7 | ref tampilInfo = true
</script>
<template>
 <!-- TODO 2: klasifikasi stok (v-if / v-else-if / v-else, BERURUTAN):
 stok = 0 -> 'Tidak Tersedia'
 stok 1-3 -> 'Terbatas'
 stok > 3 -> 'Banyak' -->
 <!-- TODO 3: tombol untuk toggle tampilInfo -->
 <p v-show="tampilInfo">Informasi koleksi diperbarui hari ini</p>
</template>
