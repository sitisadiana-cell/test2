
 // src/data/buku.js
const buku = [
  {
    id: 1,
    judul: 'Dasar Jaringan Komputer',
    penulis: 'Dr. Heni Sulistiani',
    stok: 8,
    kategori: 'Referensi'
  },
  {
    id: 2,
    judul: 'Interaksi Manusia Komputer',
    penulis: 'Yusra Fernando, M.Kom.',
    stok: 3,
    kategori: 'Skripsi'
  },
  {
    id: 3,
    judul: 'Bisnis Digital',
    penulis: 'Sari Wulandari, M.Kom.',
    stok: 0,
    kategori: 'Referensi'
  },
  {
    id: 4,
    judul: 'Pemrograman JavaScript',
    penulis: 'Budi Haryanto',
    stok: 5,
    kategori: 'Novel'
  },
  {
    id: 5,
    judul: 'Basis Data',
    penulis: 'Siti Aminah, M.Kom.',
    stok: 4,
    kategori: 'Referensi'
  },
  {
    id: 6,
    judul: 'Pemrograman Python',
    penulis: 'Andi Pratama',
    stok: 6,
    kategori: 'Referensi'
  },
  {
    id: 7,
    judul: 'Kecerdasan Buatan',
    penulis: 'Rina Safitri',
    stok: 7,
    kategori: 'Referensi'
  }
];

// Menghitung total seluruh stok buku
export const totalStok = (list) =>
  list.reduce((total, b) => total + b.stok, 0);

// Membuat format judul dan nama penulis
export const formatJudul = (judul, penulis) =>
  `${judul} oleh ${penulis}`;

// Export data buku
export default buku;
