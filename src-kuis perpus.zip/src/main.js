import './assets/main.css'
import buku, { totalStok } from './data/buku'

console.log(totalStok(buku))

import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'

const app = createApp(App)

app.use(createPinia())
app.use(router)

app.mount('#app')
